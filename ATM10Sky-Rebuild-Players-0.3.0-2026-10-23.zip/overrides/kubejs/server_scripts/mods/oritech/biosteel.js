// This File has been authored by AllTheMods Staff, or a Community contributor for use in AllTheMods.
// As all AllTheMods packs are licensed under All Rights Reserved, this file is not allowed to be used in any public packs not released by the AllTheMods Team, without explicit permission.

ServerEvents.recipes((allthemods) => {
  // A collection of scripts to help resolve conflicts between steel and biosteel
  allthemods.remove([
    { input: "#c:ingots/steel", output: "alltheores:steel_block", type: "minecraft:crafting_shaped" },
    { input: "#c:ingots/steel", output: "alltheores:steel_block", type: "minecraft:crafting_shapeless" }
  ])
  allthemods
    .shaped(Item.of("alltheores:steel_block"), ["SSS", "SAS", "SSS"], {
      S: "#c:ingots/steel",
      A: "alltheores:steel_ingot"
    })
    .id("alltheores:steel_block")

  allthemods.remove([
    { input: "#c:storage_blocks/steel", output: "alltheores:steel_ingot", type: "minecraft:crafting_shaped" },
    { input: "#c:storage_blocks/steel", output: "alltheores:steel_ingot", type: "minecraft:crafting_shapeless" }
  ])
  allthemods
    .shapeless(Item.of("alltheores:steel_ingot", 9), ["alltheores:steel_block"])
    .id("alltheores:steel_ingot_from_block")

  allthemods.replaceInput(
    { id: "productivemetalworks:melting/ingots/steel" },
    "#c:ingots/steel",
    "alltheores:steel_ingot"
  )
  allthemods.replaceInput(
    { id: "productivemetalworks:melting/storage_blocks/steel" },
    "#c:storage_blocks/steel",
    "alltheores:steel_block"
  )

  // Biosteel compatibility for making casts
  function casting_tag(input, output) {
    allthemods
      .custom({
        type: "productivemetalworks:item_casting",
        cast: {
          tag: input
        },
        consume_cast: true,
        fluid: {
          amount: 360,
          fluid: "oritech:still_molten_biosteel"
        },
        result: {
          count: 1,
          id: output
        }
      })
      .id(`allthemods:casting/cast/${output.split(":")[1]}_with_biosteel`)
  }
  function casting(input, output) {
    allthemods
      .custom({
        type: "productivemetalworks:item_casting",
        cast: {
          item: input
        },
        consume_cast: true,
        fluid: {
          amount: 360,
          fluid: "oritech:still_molten_biosteel"
        },
        result: {
          count: 1,
          id: output
        }
      })
      .id(`allthemods:casting/cast/${output.split(":")[1]}_with_biosteel`)
  }

  casting_tag("c:rods", "productivemetalworks:rod_cast")
  casting_tag("c:ingots", "productivemetalworks:ingot_cast")
  casting_tag("c:plates", "productivemetalworks:plate_cast")
  // Not using a function for pouring bricks over biosteel to allow the ID to be separate from the ingot version of the Ingot Cast recipe
  allthemods
    .custom({
      type: "productivemetalworks:item_casting",
      cast: {
        item: "minecraft:brick"
      },
      consume_cast: true,
      fluid: {
        amount: 360,
        fluid: "oritech:still_molten_biosteel"
      },
      result: {
        count: 1,
        id: "productivemetalworks:ingot_cast"
      }
    })
    .id(`allthemods:casting/cast/ingot_cast_with_biosteel_and_a_brick`)
  casting_tag("c:gems", "productivemetalworks:gem_cast")
  casting_tag("c:gears", "productivemetalworks:gear_cast")
  casting_tag("c:nuggets", "productivemetalworks:nugget_cast")
})

// This File has been authored by AllTheMods Staff, or a Community contributor for use in AllTheMods.
// As all AllTheMods packs are licensed under All Rights Reserved, this file is not allowed to be used in any public packs not released by the AllTheMods Team, without explicit permission.
