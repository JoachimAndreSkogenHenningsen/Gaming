let $Stopwatch = Java.loadClass("com.google.common.base.Stopwatch")

KubeJSTweaks.beforeRecipes((event) => {
  let timer = $Stopwatch.createStarted()

  event.dumpErroringRecipes()

  // Upgrade from forge to neoforge conditions
  event.fixCondition(["apotheosis:book"])

  // Adds mod condition based on type, using the namespace
  event
    .getEntry("productivebees:elementalcraft/pureinfusion/pure_crystal_bee")
    .forEach((entry) => entry.addModConditionFromType())

  // Fix "item" -> "id"
  event.fixItemAtKey(
    [/^create:crushing\/gloomslate_/, /^create:crushing\/sculk_stone_/, /^create:cutting\/.*echo_/],
    "results"
  )


  // Simple key renaming to match current changes
  event.getEntry(/^createaddition:compat\/immersiveengineering\/rolling\//).forEach((entry) => {
    entry.renameKey("result", "results", true)
    entry.renameKey("input", "ingredients", true)
  })

  // Simple key renaming to match current changes
  event.getEntry("createaddition:compat/ae2/charged_certus_quartz").forEach((entry) => {
    entry.renameKey("result", "results", true)
    entry.renameKey("ingredient", "ingredients", true)
  })

  // this is the way now with biome_predicates
  event.getEntry("createaddition:compat/immersiveengineering/sphalerite").forEach((entry) => {
    entry.json().add("biome_predicates", [["minecraft:is_overworld"]])
  })

  //old recipe
  event.disable("oritech:compat/enderio/firecrafting/sculk")
  event.disable("oritech:compat/enderio/firecrafting/endstone")

  // Scans items on result and add them back as conditions, izi fix
  event.getEntry(/^farmingforblockheads:market\//).forEach((entry) => {
    entry.addConditionsFromKey("result")
  })

  // Scans items/tags on ingredients and add them back as conditions
  event.getEntry("create:crafting/tree_fertilizer").forEach((entry) => {
    entry.addConditionsFromKey("ingredients")
  })


  event.getEntry("botanypots:allthemodium/crop/ancient_soulberries").forEach((entry) => {
    entry.addConditionsFromKey("input")
  })

  // Raw ore blocks smelt into a full metal block, so they should take 9x as long as a single raw ore
  event.getEntry(/^alltheores:smelting\/\w+\/raw_block_(smelting|blasting)$/).forEach((entry) => {
    let json = entry.json()
    json.addProperty("cookingtime", json.get("cookingtime").getAsInt() * 9)
    json.addProperty("experience", json.get("experience").getAsFloat() * 9)
  })

  // Squeezer resolves the raw uranium tag to a random item each launch, pin it to the unified one
  event.getEntry(/^integrateddynamics:(mechanical_)?squeezer\/ore\/raw_uranium$/).forEach((entry) => {
    for (let out of entry.json().getAsJsonArray("output_items")) {
      let tag = out.remove("tag")
      if (tag == null) continue
      out.add("item", {
        id: "alltheores:raw_uranium",
        count: tag.has("count") ? tag.get("count").getAsInt() : 1
      })
    }
  })

  console.log(`Fixing recipes took ${timer.stop().elapsed("milliseconds")} ms...`)
})
