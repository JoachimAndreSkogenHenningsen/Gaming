ATM10Sky Rebuild 0.3.0 — private player pack

Import this ZIP as a new CurseForge profile. Keep Minecraft 1.21.1, NeoForge 21.1.250 and Java 21. Use 5 GiB (5120 MiB) allocated memory to match local validation. Do not use Update All. Install this as a new profile; do not overwrite a profile containing a world you want to keep.

This version removes Railcraft Reborn, Aether, Astral Dimension and Undergarden; preserves the ATM Star/component recipes and retained technology progression; and adds ImmediatelyFast, ServerCore, Get It Together Drops, Entity Culling, BadOptimizations, More Culling and ScalableLux. It includes config, tag, loot, recipe and guidebook compatibility repairs.

All 253 managed mod files and two managed resource packs are pinned in manifest.json, including KubeJS build 374. Four additional unmodified optimizer JARs are included under overrides/mods. Keep those files; they are part of the tested pack. BUNDLED-MODS.json and modlist.html record their publishers and exact versions. More Culling requires the included Sodium 0.8.13 and Cloth Config 15.

Use the matching ATM10Sky Rebuild 0.3.0 server. No saved worlds, player data, caches, logs or temporary test helpers are included. Existing worlds that used removed mods require a separate migration decision.

Based on All the Mods 10: To the Sky by the AllTheMods Team, with private changes for Joachim and Nicholas. Original mod and pack licenses remain applicable. This is a private rebuild, not an official AllTheMods release. Each bundled JAR is unchanged and retains its notices. Source and publisher links are recorded with the bundled mod list.
